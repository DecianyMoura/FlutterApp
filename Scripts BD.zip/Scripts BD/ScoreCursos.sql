-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 26-Maio-2023 às 01:30
-- Versão do servidor: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scorecursos`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `alunos`
--

CREATE TABLE `alunos` (
  `idAlunos` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `contato` varchar(20) DEFAULT NULL,
  `cpf` varchar(20) DEFAULT NULL,
  `endereço` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cursocancelado`
--

CREATE TABLE `cursocancelado` (
  `idCursocancelado` int(11) NOT NULL,
  `idCursos` int(11) DEFAULT NULL,
  `idAlunos` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cursoemandamento`
--

CREATE TABLE `cursoemandamento` (
  `idCursoemandamento` int(11) NOT NULL,
  `idCursos` int(11) DEFAULT NULL,
  `idAlunos` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cursofinalizado`
--

CREATE TABLE `cursofinalizado` (
  `idCursofinalizado` int(11) NOT NULL,
  `idCursos` int(11) DEFAULT NULL,
  `idAlunos` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cursos`
--

CREATE TABLE `cursos` (
  `idCursos` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `duração` varchar(50) DEFAULT NULL,
  `descrição` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alunos`
--
ALTER TABLE `alunos`
  ADD PRIMARY KEY (`idAlunos`);

--
-- Indexes for table `cursocancelado`
--
ALTER TABLE `cursocancelado`
  ADD PRIMARY KEY (`idCursocancelado`),
  ADD KEY `idCursos` (`idCursos`),
  ADD KEY `idAlunos` (`idAlunos`);

--
-- Indexes for table `cursoemandamento`
--
ALTER TABLE `cursoemandamento`
  ADD PRIMARY KEY (`idCursoemandamento`),
  ADD KEY `idCursos` (`idCursos`),
  ADD KEY `idAlunos` (`idAlunos`);

--
-- Indexes for table `cursofinalizado`
--
ALTER TABLE `cursofinalizado`
  ADD PRIMARY KEY (`idCursofinalizado`),
  ADD KEY `idCursos` (`idCursos`),
  ADD KEY `idAlunos` (`idAlunos`);

--
-- Indexes for table `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`idCursos`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alunos`
--
ALTER TABLE `alunos`
  MODIFY `idAlunos` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cursocancelado`
--
ALTER TABLE `cursocancelado`
  MODIFY `idCursocancelado` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cursoemandamento`
--
ALTER TABLE `cursoemandamento`
  MODIFY `idCursoemandamento` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cursofinalizado`
--
ALTER TABLE `cursofinalizado`
  MODIFY `idCursofinalizado` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cursos`
--
ALTER TABLE `cursos`
  MODIFY `idCursos` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `cursocancelado`
--
ALTER TABLE `cursocancelado`
  ADD CONSTRAINT `cursocancelado_ibfk_1` FOREIGN KEY (`idCursos`) REFERENCES `cursos` (`idCursos`),
  ADD CONSTRAINT `cursocancelado_ibfk_2` FOREIGN KEY (`idAlunos`) REFERENCES `alunos` (`idAlunos`);

--
-- Limitadores para a tabela `cursoemandamento`
--
ALTER TABLE `cursoemandamento`
  ADD CONSTRAINT `cursoemandamento_ibfk_1` FOREIGN KEY (`idCursos`) REFERENCES `cursos` (`idCursos`),
  ADD CONSTRAINT `cursoemandamento_ibfk_2` FOREIGN KEY (`idAlunos`) REFERENCES `alunos` (`idAlunos`);

--
-- Limitadores para a tabela `cursofinalizado`
--
ALTER TABLE `cursofinalizado`
  ADD CONSTRAINT `cursofinalizado_ibfk_1` FOREIGN KEY (`idCursos`) REFERENCES `cursos` (`idCursos`),
  ADD CONSTRAINT `cursofinalizado_ibfk_2` FOREIGN KEY (`idAlunos`) REFERENCES `alunos` (`idAlunos`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
